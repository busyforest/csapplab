/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_399()
{
    return 3284633928U;
}

void setval_292(unsigned *p)
{
    *p = 2455242321U;
}

unsigned getval_344()
{
    return 4123219999U;
}

unsigned getval_380()
{
    return 3284634056U;
}

unsigned addval_439(unsigned x)
{
    return x + 2425444522U;
}

void setval_258(unsigned *p)
{
    *p = 2445773128U;
}

unsigned getval_115()
{
    return 2425393240U;
}

unsigned getval_120()
{
    return 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_493(unsigned *p)
{
    *p = 3247493513U;
}

void setval_127(unsigned *p)
{
    *p = 3526938249U;
}

unsigned addval_187(unsigned x)
{
    return x + 3353381192U;
}

unsigned addval_320(unsigned x)
{
    return x + 3351415186U;
}

unsigned addval_347(unsigned x)
{
    return x + 3281044097U;
}

unsigned addval_300(unsigned x)
{
    return x + 2425409193U;
}

unsigned addval_118(unsigned x)
{
    return x + 3677930185U;
}

unsigned addval_324(unsigned x)
{
    return x + 3281044109U;
}

unsigned getval_414()
{
    return 3281047177U;
}

unsigned getval_466()
{
    return 3526935177U;
}

void setval_418(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_312()
{
    return 3281044105U;
}

unsigned addval_425(unsigned x)
{
    return x + 2425668233U;
}

void setval_237(unsigned *p)
{
    *p = 2496760207U;
}

void setval_357(unsigned *p)
{
    *p = 3532964489U;
}

void setval_471(unsigned *p)
{
    *p = 3674787529U;
}

void setval_392(unsigned *p)
{
    *p = 2425409929U;
}

unsigned getval_139()
{
    return 3767093354U;
}

unsigned getval_156()
{
    return 3234124169U;
}

unsigned addval_238(unsigned x)
{
    return x + 3224949129U;
}

unsigned getval_174()
{
    return 2425409993U;
}

unsigned getval_202()
{
    return 2464188744U;
}

unsigned addval_129(unsigned x)
{
    return x + 1925697161U;
}

unsigned addval_435(unsigned x)
{
    return x + 2425409993U;
}

void setval_193(unsigned *p)
{
    *p = 3675836041U;
}

void setval_143(unsigned *p)
{
    *p = 2497743176U;
}

void setval_230(unsigned *p)
{
    *p = 3683963273U;
}

unsigned getval_389()
{
    return 3286272344U;
}

unsigned getval_103()
{
    return 2425409163U;
}

void setval_360(unsigned *p)
{
    *p = 2497743176U;
}

void setval_247(unsigned *p)
{
    *p = 3375943309U;
}

unsigned addval_138(unsigned x)
{
    return x + 3286272328U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
